package bulaniclientguard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class BulaniClientGuard extends JFrame {
  private JLabel label1;
  private JButton btn1;
  private JButton btn2;
  private String address = "No alarms";
  private int phase = 0;

  public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> new BulaniClientGuard().setVisible(true));

  }

  public BulaniClientGuard() {
     
    setTitle("Guard");

    setLayout(new FlowLayout());

    setSize(300, 150);

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    label1 = new JLabel("No alarms");

    label1.setPreferredSize(new Dimension(250, 25));

   btn1 = new JButton("On my way");

    btn2 = new JButton("Send backup");

    btn1.setVisible(false);

    btn2.setVisible(false);

    add(label1);

    add(btn1);

    add(btn2);

    btn1.addActionListener(new ActionListener() {

      @Override

      public void actionPerformed(ActionEvent e) {
        phase++;
        updateButtonStates();

      }

    });

    btn2.addActionListener(new ActionListener() {

      @Override
      public void actionPerformed(ActionEvent e) {

      }

    });

    Timer timer = new Timer(3000, new ActionListener() {

      @Override

      public void actionPerformed(ActionEvent e) {

        connectToServer();
      }

    });

    timer.start();
  }

  private void connectToServer() {

    new Thread(() -> {

      try {

        Socket socket = new Socket("localhost", 4321);
       
        DataOutputStream output = new DataOutputStream(socket.getOutputStream());
        DataInputStream input = new DataInputStream(socket.getInputStream());
        output.writeUTF("Guard");
        address = input.readUTF();
        SwingUtilities.invokeLater(() -> {
          label1.setText(address);
          if ("No alarms".equals(address)) {
            btn1.setVisible(false);
            btn2.setVisible(false);
            phase = 0;
          } else {

            btn1.setVisible(true);

            updateButtonStates();

          }

        });

        String action = getActionMessage();
        output.writeUTF(action);
        System.out.println("Sent: " + action);
        socket.close();
      } catch (IOException ex) {
        System.out.println("Connection failed");

      }

    }).start();

  }

  private void updateButtonStates() {

    switch (phase) {

      case 0:
        btn1.setText("On my way");
        btn2.setVisible(false);
        break;

      case 1:
        btn1.setText("Arrived");
        btn2.setVisible(false);
        break;

      case 2:
        btn1.setText("Location save");
        btn2.setVisible(true);
        break;

      case 3:
        btn1.setVisible(false);
        btn2.setVisible(false);
        Timer resetTimer = new Timer(2000, e -> {
          phase = 0;
          address = "No alarms";
          label1.setText("No alarms");
        });
        resetTimer.setRepeats(false);
        resetTimer.start();
        break;

    }

  }

  private String getActionMessage() {

    switch (phase) {
      case 0:
        return "No action";

      case 1:
        return "Guard on his way";

      case 2:
        return "Guard arrived";

      case 3:
        return "House is save";

      default:

        return "No action";

    }

  }

}