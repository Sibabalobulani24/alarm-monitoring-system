
package bulaniclienthome;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class BulaniClientHome extends Application {
  private boolean armed = false;
  private int step = 0;
  private String code = "132";

  public static void main(String[] args) {

    launch(args);

  }

  @Override
  public void start(Stage stage) throws Exception {
    GridPane layout = new GridPane();
    Button btn_Move = new Button("MOVE");
    Button btn_Armed = new Button("DISARMED");
    Button btn_1 = new Button("1");
    Button btn_2 = new Button("2");
    Button btn_3 = new Button("3");
    TextField textField = new TextField("Symphony way 123");           
    layout.add(btn_Armed, 0, 0);
    layout.add(btn_Move, 1, 0);
    layout.add(textField, 2, 0);
    layout.add(btn_1, 0, 1);
    layout.add(btn_2, 1, 1);
    layout.add(btn_3, 2, 1);
    
    Scene scene = new Scene(layout, 500, 150);
    stage.setScene(scene);
    stage.setTitle("Home Alarm");
    stage.show();
          
    btn_1.setOnAction(e -> checkCode("1"));

    btn_2.setOnAction(e -> checkCode("2"));

    btn_3.setOnAction(e -> checkCode("3"));
    
    
    btn_Armed.setOnAction(new EventHandler<ActionEvent>() {

      @Override

      public void handle(ActionEvent event) {

        armed = !armed;

        btn_Armed.setText(armed ? "ARMED" : "DISARMED");

      }

    });
     
     
    btn_Move.setOnAction(new EventHandler<ActionEvent>() {

      @Override

      public void handle(ActionEvent e) {

        if (armed) {

          sendAlarm(textField.getText());  

        }

      }

      private void sendAlarm(String address) {

        try {

          Socket socket = new Socket("localhost", 4321);
          

          DataOutputStream output = new DataOutputStream(socket.getOutputStream());

          output.writeUTF("Home");

          output.writeUTF(address);

          socket.close(); 

          System.out.println("Alarm sent: " + address); 

        } catch (IOException ex) {

          System.out.println("Failed to send alarm");

        }

      }

    });

  }

  private void checkCode(String digit) {

    if (step < code.length() && code.charAt(step) == digit.charAt(0)) {

      step++;

      if (step == code.length()) {

        armed = !armed;

        step = 0;

        System.out.println("Alarm " + (armed ? "ARMED" : "DISARMED")); 

      }

    } else {

      step = 0; 

      System.out.println("Wrong code - reset"); 

    }

  }

}