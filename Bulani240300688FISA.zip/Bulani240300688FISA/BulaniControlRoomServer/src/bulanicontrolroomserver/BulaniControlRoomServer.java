package bulanicontrolroomserver;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;


public class BulaniControlRoomServer {
  private static String address = "No alarms";
  private static boolean dispatch = false;
  public static void main(String[] args) throws IOException {
  ServerSocket serverSocket = new ServerSocket(4321);
    System.out.println("Server started on port 4321");

    while(true) {

      Socket socket = serverSocket.accept();
      System.out.println("Client connected"); 
      DataInputStream input = new DataInputStream(socket.getInputStream());
      DataOutputStream output = new DataOutputStream(socket.getOutputStream());
       String clientType = input.readUTF();
      System.out.println("Client type: " + clientType); 

      if ("Home".equals(clientType)) {

        address = input.readUTF();

        System.out.println("Alarm from: " + address);

          int choice = JOptionPane.showOptionDialog(null,

          "Dispatch guard to " + address + "?",

          "Alarm Dispatch",

          JOptionPane.YES_NO_CANCEL_OPTION,

          JOptionPane.QUESTION_MESSAGE,

          null, null, null);

        dispatch = (choice == JOptionPane.YES_OPTION);

        System.out.println("Dispatch: " + dispatch);

      } else if ("Guard".equals(clientType)) {


        if (dispatch && !"No alarms".equals(address)) {

          output.writeUTF(address);

        } else {

          output.writeUTF("No alarms");

        }

        String action = input.readUTF();

        if (!"No action".equals(action)) {

          System.out.println("=== GUARD ACTION ===");

          System.out.println("Guard: " + action);

          System.out.println("===================");

          if ("House is save".equals(action)) {

            address = "No alarms";

            dispatch = false;

            System.out.println("=== SYSTEM RESET ===");

            System.out.println("Ready for next alarm");

            System.out.println("===================");

          }

        } else {

          System.out.println("Guard: No action required");

        }

      } else {
        
        System.out.println("Unknown client type: " + clientType);

      }

      socket.close(); 

    }

  }

}